#include <iostream>
#include <windows.h>
#include <conio.h>
using namespace std;

#pragma comment(lib,"msimg32.lib")

HWND hwnd = GetConsoleWindow(); 
HDC hdc = GetDC(hwnd); 

void main()
{
	SetConsoleTitleA("�hebyrashka");

	HPEN white_pen = CreatePen(PS_SOLID,4,RGB(0,128,0));
	HBRUSH white_brush = CreateSolidBrush(RGB(0,255,0));

	SelectObject(hdc,white_pen);
	SelectObject(hdc,white_brush);
	Ellipse(hdc,230,100,275+110,110+200);
	DeleteObject(white_pen);
	DeleteObject(white_brush);
	HPEN red_pen = CreatePen(PS_SOLID,1,RGB(0,255,0));
	HBRUSH red_brush = CreateSolidBrush(RGB(0,255,0));

	SelectObject(hdc,red_pen);
	SelectObject(hdc,red_brush);
    
	Ellipse(hdc,270,60,275+70,110+10);
	Ellipse(hdc,280,47,275+60,87);
	DeleteObject(red_pen);
	DeleteObject(red_brush);
	
	SelectObject(hdc,white_pen);
	SelectObject(hdc,white_brush);
	Ellipse(hdc,210,225,240,110+145);
	Ellipse(hdc,375,225,405,110+145);
	Rectangle(hdc,270,290,292,120+230);
	Rectangle(hdc,330,290,351,120+230);
	
	DeleteObject(white_pen);
	DeleteObject(white_brush);
	HPEN black_pen = CreatePen(PS_SOLID,1,RGB(0,128,0));
	HBRUSH black_brush = CreateSolidBrush(RGB(168,0,168));
	SelectObject(hdc,black_pen);
	SelectObject(hdc,black_brush);
	Rectangle(hdc,269,327,293,120+220);
	Rectangle(hdc,329,327,352,120+220);
	Rectangle(hdc,280,53,275+60,65);
	DeleteObject(black_pen);
	DeleteObject(black_brush);
	HPEN a_pen = CreatePen(PS_SOLID,1,RGB(121,121,0));
	HBRUSH a_brush = CreateSolidBrush(RGB(121,121,0));
	SelectObject(hdc,a_pen);
	SelectObject(hdc,a_brush);
	Rectangle(hdc,382,57,400,352);
	DeleteObject(a_pen);
	DeleteObject(a_brush);
	HPEN b_pen = CreatePen(PS_SOLID,1,RGB(255,242,0));
	HBRUSH b_brush = CreateSolidBrush(RGB(255,242,0));
	SelectObject(hdc,b_pen);
	SelectObject(hdc,b_brush);
	Rectangle(hdc,266,125,350,180+50);
	Ellipse(hdc,266,180,350,280);
	DeleteObject(b_pen);
	DeleteObject(b_brush);
	HPEN c_pen = CreatePen(PS_SOLID,1,RGB(255,204,221));
	HBRUSH c_brush = CreateSolidBrush(RGB(255,204,221));
	SelectObject(hdc,c_pen);
	SelectObject(hdc,c_brush);
	Rectangle(hdc,382,148,400,250);







	HANDLE h=GetStdHandle(STD_OUTPUT_HANDLE);

	CONSOLE_CURSOR_INFO cci;
	cci.bVisible=0;
	cci.dwSize=100;
	SetConsoleCursorInfo(h,&cci);
	Sleep(INFINITE);
}