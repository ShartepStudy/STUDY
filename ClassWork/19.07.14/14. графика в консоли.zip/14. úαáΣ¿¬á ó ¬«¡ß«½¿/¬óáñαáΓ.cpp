#include <iostream>
#include <windows.h>
#include <conio.h>
using namespace std;

#pragma comment(lib,"msimg32.lib")
void main()
{
	SetConsoleTitleA("JAPAN");
	HWND hwnd = GetConsoleWindow(); 
HDC hdc = GetDC(hwnd);

	HPEN white_pen = CreatePen(PS_SOLID,1,RGB(255,128,223));
	HBRUSH white_brush = CreateSolidBrush(RGB(128,255,0));

	SelectObject(hdc,white_pen);
	SelectObject(hdc,white_brush);
	POINT p;
	MoveToEx(hdc,0,0,&p);
	LineTo(hdc,200,0);
	LineTo(hdc,200,200);
	LineTo(hdc,0,200);
	LineTo(hdc,0,0);
	LineTo(hdc,200,200);
	LineTo(hdc,0,200);
	LineTo(hdc,200,0);
	LineTo(hdc,200,100);
	LineTo(hdc,0,100);
	LineTo(hdc,0,0);
	LineTo(hdc,100,0);
	LineTo(hdc,100,200);
	FloodFill(hdc,50,180,RGB(255,128,223));
	DeleteObject(white_brush);
	white_brush=CreateSolidBrush(RGB(250,0,0));
	SelectObject(hdc,white_brush);
	FloodFill(hdc,190,125,RGB(255,128,223));
	DeleteObject(white_brush);
	white_brush=CreateSolidBrush(RGB(0,250,0));
	SelectObject(hdc,white_brush);
	FloodFill(hdc,100,15,RGB(255,128,223));
	DeleteObject(white_brush);
	white_brush=CreateSolidBrush(RGB(255,255,255));
	SelectObject(hdc,white_brush);
	FloodFill(hdc,5,150,RGB(255,128,223));
	DeleteObject(white_brush);
	white_brush=CreateSolidBrush(RGB(57,61,204));
	SelectObject(hdc,white_brush);
	FloodFill(hdc,30,90,RGB(255,128,223));
	HANDLE h=GetStdHandle(STD_OUTPUT_HANDLE);
	white_brush=CreateSolidBrush(RGB(236,26,94));
	SelectObject(hdc,white_brush);
	FloodFill(hdc,80,55,RGB(255,128,223));
	DeleteObject(white_brush);
	white_brush=CreateSolidBrush(RGB(250,243,12));
	SelectObject(hdc,white_brush);
	FloodFill(hdc,130,75,RGB(255,128,223));
	DeleteObject(white_brush);
	white_brush=CreateSolidBrush(RGB(2,211,50));
	SelectObject(hdc,white_brush);
	FloodFill(hdc,120,10,RGB(255,128,223));
	DeleteObject(white_brush);
	white_brush=CreateSolidBrush(RGB(205,7,166));
	SelectObject(hdc,white_brush);
	FloodFill(hdc,110,170,RGB(255,128,223));
	
	cout<<"\n\n\n\n\t\t\t televicor""\n";
	CONSOLE_CURSOR_INFO cci;
	cci.bVisible=0;
	cci.dwSize=100;
	SetConsoleCursorInfo(h,&cci);
	Sleep(INFINITE);
}
