
#include <iostream>
#include <windows.h>
#include <conio.h>
using namespace std;

const int PointCount=12;

HWND hwnd = GetConsoleWindow();
HDC hdc = GetDC(hwnd);

int Xmass[PointCount]={20,90,90,110,110,150,110,150,150,220,190,50};
int Ymass[PointCount]={110,110,130,130,10,70,130,130,120,120,160,160};

void DrawShip(int x, int y){
	POINT p;
	MoveToEx(hdc,Xmass[0]+x,Ymass[0]+y,&p);
	HPEN pen = CreatePen(PS_SOLID,1,RGB(100,100,100));
	SelectObject(hdc,pen);
	for(int i=0;i<PointCount;i++){
		LineTo(hdc,Xmass[i]+x,Ymass[i]+y);
	}
	LineTo(hdc,Xmass[0]+x,Ymass[0]+y);

	HBRUSH white_brush = CreateSolidBrush(RGB(255,255,255));
	SelectObject(hdc,white_brush);
	FloodFill(hdc,111+x,70+y,RGB(100,100,100));

	HBRUSH brown_brush = CreateSolidBrush(RGB(128,0,0));
	SelectObject(hdc,brown_brush);
	FloodFill(hdc,30+x,120+y,RGB(100,100,100));
}

void CleanScreen(int x){
	HPEN black_pen = CreatePen(PS_SOLID,1,RGB(0,0,0));
	SelectObject(hdc,black_pen);
	HBRUSH black_brush = CreateSolidBrush(RGB(0,0,0));
	SelectObject(hdc,black_brush);
	Rectangle(hdc,x,0,800,210);
}

void Sea(int color_diff){
	HPEN blue_pen = CreatePen(PS_SOLID,1,RGB(0+color_diff/2,0,200));
	SelectObject(hdc,blue_pen);
	HBRUSH blue_brush = CreateSolidBrush(RGB(0+color_diff/2,0,200));
	SelectObject(hdc,blue_brush);
	Rectangle(hdc,0,210,800,350);
}

void Sky(int color_diff){
	HPEN cyan_pen = CreatePen(PS_SOLID,1,RGB(color_diff,150,200));
	SelectObject(hdc,cyan_pen);
	HBRUSH cyan_brush = CreateSolidBrush(RGB(color_diff,150,200));
	SelectObject(hdc,cyan_brush);
	Rectangle(hdc,0,0,800,210);
}

void Sun(int x,int y){
	HPEN yellow_pen = CreatePen(PS_SOLID,1,RGB(255,255-x/2,0));
	SelectObject(hdc,yellow_pen);
	HBRUSH yellow_brush = CreateSolidBrush(RGB(255,255-x/2,0));
	SelectObject(hdc,yellow_brush);
	Ellipse(hdc,50+x/3,50+y/3,150+x,150+y);
}

void main(){

	SetConsoleTitleA("Ship");
	for(int x=0;x<1000;x++){
		DrawShip(x,50);
		Sleep(15);
		Sky(x/4);
		Sun(x/3,x/3);
		Sea(x/3);
	}
	HANDLE h=GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_CURSOR_INFO cci;
	cci.bVisible=0;
	cci.dwSize=100;
	SetConsoleCursorInfo(h,&cci);
	Sleep(INFINITE);

}