/// ���� �������� ////////
# include <iostream>
# include <Windows.h>

using namespace std;

#define STANDART_TEXT 7

// ���������� ������
HANDLE h= GetStdHandle (STD_OUTPUT_HANDLE);
HDC hdc;

void line (int x1, int y1, int x2, int y2, int clr, int thick )
{
	HPEN pen = CreatePen (PS_SOLID, thick, clr);
	HPEN oldpen = (HPEN) SelectObject (hdc, pen);
	MoveToEx(hdc, x1, y1, 0);
	LineTo (hdc, x2, y2);
	SelectObject (hdc, oldpen);
	DeleteObject (pen);
	
}

void main()
{
	system ("mode con cols=80 lines=325");
	setlocale(0,"Russian");
	
	HWND hwnd = GetConsoleWindow();
	hdc=GetDC(hwnd);
	
	HPEN red_pen=CreatePen(PS_SOLID, 1, RGB(255,0,0));
	HBRUSH red_brush=CreateSolidBrush(RGB(255,0,0));
	HPEN blue_pen=CreatePen(PS_SOLID,1, RGB(0,0,255));
	HBRUSH blue_brush=CreateSolidBrush(RGB(0,0,255));
	HPEN white_pen=CreatePen(PS_SOLID, 1, RGB(255,255,255));
	HBRUSH white_brush=CreateSolidBrush(RGB(255,255,255));
	
		SelectObject(hdc,white_pen);
		SelectObject(hdc,white_brush);
		
		// ����� ���
		Rectangle(hdc, 100, 100, 300, 172);
				
		SelectObject(hdc,blue_pen);
		SelectObject(hdc,blue_brush);
		
		//����� �������
		Rectangle(hdc, 100, 100, 170, 126);
		Rectangle(hdc, 100, 146, 170, 172);
		Rectangle(hdc, 230, 100, 300, 126);
		Rectangle(hdc, 230, 146, 300, 172);

		SelectObject(hdc,blue_pen);
		SelectObject(hdc,blue_brush);

		
		line(100, 100, 300, 172, RGB(255,255,255), 10);
		line(100, 172, 300, 100, RGB(255,255,255), 10);
		line(100, 100, 300, 172, RGB(255,0,0), 4);
		line(100, 172, 300, 100, RGB(255,0,0), 4);
		line(98, 100, 98, 174, RGB(0,0,0), 6);
		line(98, 174, 302, 174, RGB(0,0,0), 6);
		line(302, 100, 302, 174, RGB(0,0,0), 6);
		
		SelectObject(hdc,red_pen); // � ��� ������� ���-�� �� �� �����
		SelectObject(hdc,red_pen); // ���� �����
		
		/*Rectangle(hdc, 174, 100, 226, 172);*/ // ���� �����.. �� �� ���� ��� :(
		/*Rectangle(hdc, 100, 128, 300, 143);*/
		
		DeleteObject(white_pen);
		DeleteObject(white_brush);
		DeleteObject(blue_pen);
		DeleteObject(blue_brush);
		DeleteObject(red_pen);
		DeleteObject(red_brush);
		ReleaseDC(hwnd, hdc);
		SetConsoleTextAttribute(h, STANDART_TEXT);
		cout<<"\n\n";
		
		
		
		
}